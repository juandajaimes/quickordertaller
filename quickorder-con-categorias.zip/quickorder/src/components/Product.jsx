export function Product({ indice, nombre, descripcion, precio, imagen, tag, onAddToCart }) {
    return (
        <article className="product-card" key={indice}>
            <div className="product-image-container">
                {tag && <span className="product-tag">{tag}</span>}
                {imagen ? (
                    <img src={imagen} alt={nombre} className="product-image" loading="lazy" />
                ) : (
                    <div className="product-image-placeholder">🍔</div>
                )}
            </div>
            <div className="product-content">
                <h3 className="product-title">{nombre}</h3>
                <p className="product-description">{descripcion}</p>
                <div className="product-footer">
                    <div className="price-wrapper">
                        <span className="price-label">Precio</span>
                        <span className="product-price">
                            {` ${precio}`}
                        </span>
                    </div>
                    <button className="btn-add-order" onClick={() => onAddToCart && onAddToCart(nombre)}>
                        <span className="btn-plus">+</span> Agregar
                    </button>
                </div>
            </div>
        </article>
    );
}